// Ported from base44/functions/fetchFuelPrices/entry.ts — scrapes UAE fuel
// prices from Gulf News and upserts them into `settings` under key
// 'fuel_prices', same as the original. No Base44-specific logic here beyond
// the client swap, so the scraping regex is untouched.
//
// Deploy:   supabase functions deploy fetch-fuel-prices --no-verify-jwt
// Schedule: see ../../cron.sql (runs monthly; also safe to call on demand)

import { createClient } from 'npm:@supabase/supabase-js@2';
import { corsHeaders, json } from '../_shared/cors.ts';

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });

  try {
    const response = await fetch('https://gulfnews.com/gold-forex/historical-fuel-rates', {
      headers: { 'User-Agent': 'Mozilla/5.0 (compatible; KannazFuelBot/1.0)' },
    });
    const html = await response.text();

    const rowRegex = /<tr[^>]*>[\s\S]*?<td[^>]*>\s*([^<]+?)\s*<\/td>[\s\S]*?<td[^>]*>\s*([\d.]+)\s*<\/td>[\s\S]*?<td[^>]*>\s*([\d.]+)\s*<\/td>[\s\S]*?<td[^>]*>\s*([\d.]+)\s*<\/td>[\s\S]*?<td[^>]*>\s*([\d.]+)\s*<\/td>[\s\S]*?<\/tr>/i;
    const match = rowRegex.exec(html);
    if (!match) return json({ error: 'Could not find fuel price data on the page' }, 500);

    const monthLabel = match[1].trim().replace(/\s+/g, ' ');
    const super98 = parseFloat(match[2]);
    const special95 = parseFloat(match[3]);
    const eplus91 = parseFloat(match[4]);
    const diesel = parseFloat(match[5]);

    if ([super98, special95, eplus91, diesel].some(isNaN)) {
      return json({ error: 'Parsed values are not valid numbers' }, 500);
    }

    const prices = {
      super_98: super98, special_95: special95, eplus_91: eplus91, diesel,
      month: monthLabel, currency: 'AED', unit: 'per litre',
      updated_at: new Date().toISOString(),
    };

    const admin = createClient(Deno.env.get('SUPABASE_URL')!, Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!);
    const { data: existing } = await admin.from('settings').select('id').eq('key', 'fuel_prices').maybeSingle();
    const valueJson = JSON.stringify(prices);

    if (existing) {
      await admin.from('settings').update({
        value: valueJson,
        description: `UAE fuel prices - ${monthLabel}`,
      }).eq('id', existing.id);
    } else {
      await admin.from('settings').insert({
        key: 'fuel_prices', value: valueJson, category: 'system',
        description: `UAE fuel prices - ${monthLabel}`,
      });
    }

    return json({ success: true, prices });
  } catch (error) {
    return json({ error: (error as Error).message }, 500);
  }
});
