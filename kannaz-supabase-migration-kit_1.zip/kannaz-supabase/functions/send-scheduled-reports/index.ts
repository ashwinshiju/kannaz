// Ported from base44/functions/sendScheduledReports/entry.ts
// Runs every 15 minutes (see ../../cron.sql), sends any `scheduled_reports`
// row whose scheduled_send_at has arrived.
//
// Deploy: supabase functions deploy send-scheduled-reports --no-verify-jwt

import { createClient } from 'npm:@supabase/supabase-js@2';
import { corsHeaders, json } from '../_shared/cors.ts';
import { buildReportRows, getTotals, buildEmailBody } from '../_shared/reportEmail.ts';
import { sendEmail } from '../_shared/sendEmail.ts';

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });

  const admin = createClient(Deno.env.get('SUPABASE_URL')!, Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!);

  // Cron calls this with no Authorization header — allowed, same as Base44's
  // no-session workflow path. A manual call must be from an admin.
  const authHeader = req.headers.get('Authorization');
  if (authHeader) {
    const caller = createClient(Deno.env.get('SUPABASE_URL')!, Deno.env.get('SUPABASE_ANON_KEY')!, {
      global: { headers: { Authorization: authHeader } },
    });
    const { data: { user } } = await caller.auth.getUser();
    if (user) {
      const { data: profile } = await admin.from('profiles').select('role').eq('id', user.id).single();
      if (profile?.role !== 'admin') return json({ error: 'Forbidden' }, 403);
    }
  }

  try {
    const now = new Date().toISOString();
    const { data: pending } = await admin.from('scheduled_reports')
      .select('*').eq('status', 'pending').lte('scheduled_send_at', now);

    if (!pending || pending.length === 0) return json({ processed: 0, failed: 0 });

    const { data: vehicles } = await admin.from('vehicles').select('*');
    const { data: employees } = await admin.from('employees').select('*');
    const vehicleMap = new Map((vehicles || []).map((v: any) => [v.id, v]));
    const employeeMap = new Map((employees || []).map((e: any) => [e.id, e]));

    let processed = 0;
    let failed = 0;

    for (const report of pending) {
      try {
        const { data: allTrips } = await admin.from('trips')
          .select('*').order('started_at', { ascending: false }).limit(5000);
        const weekTrips = (allTrips || []).filter((t: any) => {
          const ts = t.started_at || t.created_date;
          if (!ts) return false;
          return ts >= report.week_start_iso && ts <= report.week_end_iso;
        });

        const rows = buildReportRows(weekTrips, vehicleMap, employeeMap);
        const { totalDistance, totalMinutes } = getTotals(rows);
        const subject = `Weekly Trip Report – ${report.week_label}`;
        const emailBody = buildEmailBody(rows, report.week_label, totalDistance, totalMinutes);

        await sendEmail({ to: report.recipient_email, subject, body: emailBody });

        await admin.from('scheduled_reports').update({
          status: 'sent', sent_at: new Date().toISOString(), error_message: null,
        }).eq('id', report.id);
        processed++;
      } catch (err) {
        await admin.from('scheduled_reports').update({
          status: 'failed',
          error_message: String((err as Error)?.message || err).slice(0, 500),
        }).eq('id', report.id);
        failed++;
      }
    }

    return json({ processed, failed });
  } catch (error) {
    return json({ error: (error as Error).message }, 500);
  }
});
