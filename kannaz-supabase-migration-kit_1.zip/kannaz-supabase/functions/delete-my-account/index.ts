// Ported from base44/functions/deleteMyAccount/entry.ts
// Called by the signed-in user themselves (Settings.jsx -> base44.functions.invoke
// -> supabase.functions.invoke). Deletes their own data, logs the deletion,
// then removes their Supabase Auth account.
//
// Deploy: supabase functions deploy delete-my-account

import { createClient } from 'npm:@supabase/supabase-js@2';
import { corsHeaders, json } from '../_shared/cors.ts';

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });

  try {
    const authHeader = req.headers.get('Authorization');
    if (!authHeader) return json({ error: 'Unauthorized' }, 401);

    const caller = createClient(Deno.env.get('SUPABASE_URL')!, Deno.env.get('SUPABASE_ANON_KEY')!, {
      global: { headers: { Authorization: authHeader } },
    });
    const { data: { user } } = await caller.auth.getUser();
    if (!user) return json({ error: 'Unauthorized' }, 401);

    // Server-side only, from the caller's own verified identity — a caller
    // can never target another user's records.
    const userId = user.id;
    const userEmail = user.email ?? '';
    const { data: profile } = await caller.from('profiles').select('full_name').eq('id', userId).single();
    const userName = profile?.full_name || 'Unknown';

    const admin = createClient(Deno.env.get('SUPABASE_URL')!, Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!);

    // Employee rows are matched by email (that's how the app links a Supabase
    // user to an Employee record — see FuelRecordForm.jsx / AuthContext).
    const { data: employee } = await admin.from('employees').select('id').eq('email', userEmail).maybeSingle();
    const employeeId = employee?.id;

    await Promise.all([
      employeeId ? admin.from('trips').delete().eq('employee_id', employeeId) : Promise.resolve(),
      employeeId ? admin.from('fuel_records').delete().eq('employee_id', employeeId) : Promise.resolve(),
      admin.from('notifications').delete().eq('target_user_id', userId),
      admin.from('audit_logs').delete().eq('user_email', userEmail),
    ]);

    // Log the deletion after cleanup so it survives the audit_logs purge.
    await admin.from('audit_logs').insert({
      user_name: userName,
      user_email: userEmail,
      action: 'delete',
      module: 'Account',
      entity_type: 'User',
      details: 'User initiated account deletion — all associated data removed',
    });

    // Finally remove the Supabase Auth user itself (cascades to profiles).
    const { error: delErr } = await admin.auth.admin.deleteUser(userId);
    if (delErr) throw delErr;

    return json({ success: true });
  } catch (error) {
    return json({ error: (error as Error).message }, 500);
  }
});
