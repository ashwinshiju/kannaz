// Ported from base44/functions/checkMaintenanceDue/entry.ts
//
// Original used base44.asServiceRole.entities.* (bypasses Base44's RLS) and
// allowed either no session (scheduled workflow) or an admin session (manual
// call). Same shape here: the Supabase service-role key bypasses Postgres RLS
// the same way asServiceRole did, and admin is checked the same way.
//
// Deploy:  supabase functions deploy check-maintenance-due --no-verify-jwt
// Schedule: see ../../cron.sql

import { createClient } from 'npm:@supabase/supabase-js@2';
import { corsHeaders, json } from '../_shared/cors.ts';

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });

  const admin = createClient(
    Deno.env.get('SUPABASE_URL')!,
    Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!,
  );

  // Cron calls this with no Authorization header at all — that's fine, same
  // as Base44's "no session on scheduled workflows". A manual call (from the
  // app) must carry an admin's JWT.
  const authHeader = req.headers.get('Authorization');
  if (authHeader) {
    const caller = createClient(Deno.env.get('SUPABASE_URL')!, Deno.env.get('SUPABASE_ANON_KEY')!, {
      global: { headers: { Authorization: authHeader } },
    });
    const { data: { user } } = await caller.auth.getUser();
    if (user) {
      const { data: profile } = await admin.from('profiles').select('role').eq('id', user.id).single();
      if (profile?.role !== 'admin') return json({ error: 'Forbidden' }, 403);
    }
  }

  try {
    const { data: vehicles } = await admin.from('vehicles').select('*');
    const { data: existingNotifs } = await admin.from('notifications')
      .select('*').eq('type', 'maintenance').eq('is_read', false);
    const { data: maintenanceRecords } = await admin.from('maintenance_records').select('*');

    const BUFFER = 500;
    const INTERVAL = 10000;

    const newNotifications: any[] = [];
    const alerts: any[] = [];

    for (const vehicle of vehicles || []) {
      const odometer = vehicle.current_odometer || 0;
      if (odometer <= 0) continue;

      const currentMilestone = Math.floor(odometer / INTERVAL) * INTERVAL;
      const nextMilestone = currentMilestone + INTERVAL;
      const distanceToNext = nextMilestone - odometer;
      const distanceFromLast = odometer - currentMilestone;

      const isApproaching = distanceToNext > 0 && distanceToNext <= BUFFER;
      const justPassed = currentMilestone > 0 && distanceFromLast <= BUFFER;
      if (!isApproaching && !justPassed) continue;

      const alertMilestone = isApproaching ? nextMilestone : currentMilestone;

      const hasCompletedMaintenance = (maintenanceRecords || []).some((m: any) =>
        m.vehicle_id === vehicle.id &&
        m.status === 'completed' &&
        m.odometer >= alertMilestone - BUFFER &&
        m.odometer <= alertMilestone + BUFFER
      );
      if (hasCompletedMaintenance) continue;

      const alreadyNotified = (existingNotifs || []).some((n: any) =>
        n.title?.includes(vehicle.name) && n.message?.includes(alertMilestone.toLocaleString())
      );
      if (alreadyNotified) continue;

      const message = isApproaching
        ? `${vehicle.name} (${vehicle.reg_no}) is approaching ${alertMilestone.toLocaleString()} km. Current: ${odometer.toLocaleString()} km. Schedule maintenance soon.`
        : `${vehicle.name} (${vehicle.reg_no}) has crossed ${currentMilestone.toLocaleString()} km. Current: ${odometer.toLocaleString()} km. Maintenance overdue.`;

      newNotifications.push({
        title: `Maintenance Due: ${vehicle.name}`,
        message,
        type: 'maintenance',
        is_read: false,
        link: '/maintenance',
      });
      alerts.push({ vehicle: vehicle.name, reg_no: vehicle.reg_no, odometer, milestone: alertMilestone, isApproaching });
    }

    if (newNotifications.length > 0) {
      const { error } = await admin.from('notifications').insert(newNotifications);
      if (error) throw error;
    }

    return json({ alertsCreated: newNotifications.length, alerts });
  } catch (error) {
    return json({ error: (error as Error).message }, 500);
  }
});
