// Base44's `base44.integrations.Core.SendEmail` doesn't have a Supabase
// equivalent — Supabase Auth only sends its own auth emails (confirmations,
// resets), not arbitrary app email. This wraps Resend (resend.com) as a
// concrete example; swap for whatever provider you prefer, same shape.
//
// Requires a `RESEND_API_KEY` secret (and optionally `RESEND_FROM`,
// default shown below) set on the Supabase project:
//   supabase secrets set RESEND_API_KEY=re_xxx RESEND_FROM="Kannaz <reports@yourdomain.com>"

export async function sendEmail({ to, subject, body }: { to: string; subject: string; body: string }) {
  const apiKey = Deno.env.get('RESEND_API_KEY');
  const from = Deno.env.get('RESEND_FROM') || 'Kannaz <onboarding@resend.dev>';
  if (!apiKey) throw new Error('RESEND_API_KEY is not set — see functions/_shared/sendEmail.ts');

  const res = await fetch('https://api.resend.com/emails', {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${apiKey}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ from, to, subject, html: body }),
  });

  if (!res.ok) {
    const detail = await res.text().catch(() => '');
    throw new Error(`SendEmail failed (${res.status}): ${detail}`);
  }
  return res.json();
}
