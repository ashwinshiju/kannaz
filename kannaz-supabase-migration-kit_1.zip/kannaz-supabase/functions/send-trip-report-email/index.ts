// Ported from base44/functions/sendTripReportEmail/entry.ts
// Called on-demand from src/components/reports/TripReportDialog.jsx via
// supabase.functions.invoke('send-trip-report-email', { body: {...} }).
//
// Deploy: supabase functions deploy send-trip-report-email

import { createClient } from 'npm:@supabase/supabase-js@2';
import { corsHeaders, json } from '../_shared/cors.ts';
import { buildReportRows, getTotals, buildEmailBody } from '../_shared/reportEmail.ts';
import { sendEmail } from '../_shared/sendEmail.ts';

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });

  let body: any = {};
  try { body = await req.json(); } catch { /* not JSON */ }
  const { recipient_email, start_iso, end_iso, range_label } = body;

  const authHeader = req.headers.get('Authorization');
  if (!authHeader) return json({ error: 'Unauthorized' }, 401);

  const admin = createClient(Deno.env.get('SUPABASE_URL')!, Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!);
  const caller = createClient(Deno.env.get('SUPABASE_URL')!, Deno.env.get('SUPABASE_ANON_KEY')!, {
    global: { headers: { Authorization: authHeader } },
  });
  const { data: { user } } = await caller.auth.getUser();
  if (!user) return json({ error: 'Unauthorized' }, 401);

  // Auth: platform admin OR an Employee row with manager/admin role, matched
  // by email — same two-tier check as the original function.
  let authorized = false;
  const { data: profile } = await admin.from('profiles').select('role').eq('id', user.id).single();
  if (profile?.role === 'admin') {
    authorized = true;
  } else {
    const { data: emp } = await admin.from('employees').select('role').eq('email', user.email).maybeSingle();
    authorized = emp?.role === 'admin' || emp?.role === 'manager';
  }
  if (!authorized) return json({ error: 'Forbidden — managers and admins only' }, 403);

  if (!recipient_email || !range_label) {
    return json({ error: 'recipient_email and range_label are required' }, 400);
  }

  try {
    const { data: vehicles } = await admin.from('vehicles').select('*');
    const { data: employees } = await admin.from('employees').select('*');
    const vehicleMap = new Map((vehicles || []).map((v: any) => [v.id, v]));
    const employeeMap = new Map((employees || []).map((e: any) => [e.id, e]));

    const { data: allTrips } = await admin.from('trips')
      .select('*').order('started_at', { ascending: false }).limit(5000);

    const rangeTrips = (!start_iso && !end_iso)
      ? (allTrips || [])
      : (allTrips || []).filter((t: any) => {
          const ts = t.started_at || t.created_date;
          if (!ts) return false;
          if (start_iso && ts < start_iso) return false;
          if (end_iso && ts > end_iso) return false;
          return true;
        });

    const rows = buildReportRows(rangeTrips, vehicleMap, employeeMap);
    const { totalDistance, totalMinutes } = getTotals(rows);
    const subject = `Trip Report – ${range_label}`;
    const emailBody = buildEmailBody(rows, range_label, totalDistance, totalMinutes);

    await sendEmail({ to: recipient_email, subject, body: emailBody });

    return json({ sent: true, trips: rows.length });
  } catch (error) {
    return json({ error: (error as Error).message }, 500);
  }
});
