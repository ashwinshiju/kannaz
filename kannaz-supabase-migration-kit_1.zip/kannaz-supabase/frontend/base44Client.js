// Drop-in replacement for src/api/base44Client.js.
//
// Keeps the same shape every page already imports — `import { base44 } from
// '@/api/base44Client'` — with `.entities`, `.auth`, `.functions`, and
// `.integrations.Core.UploadFile` all backed by Supabase instead of Base44.
// Built from what src/**/*.jsx actually calls (checked by grep across the
// full export), not a generic guess — see the migration guide for the
// method-by-method mapping this implements.
//
// Copy this file over src/api/base44Client.js, then:
//   npm install @supabase/supabase-js
//   npm uninstall @base44/sdk @base44/vite-plugin   (and remove the
//     base44() plugin block from vite.config.js)
// and set VITE_SUPABASE_URL / VITE_SUPABASE_ANON_KEY in .env.local
// (see frontend/.env.example).

import { createClient } from '@supabase/supabase-js';

const supabase = createClient(
  import.meta.env.VITE_SUPABASE_URL,
  import.meta.env.VITE_SUPABASE_ANON_KEY,
);

// Base44 entity name -> Supabase table name (from base44/entities/*.jsonc)
const TABLES = {
  Vehicle: 'vehicles',
  Employee: 'employees',
  Department: 'departments',
  Trip: 'trips',
  TripTrackingLog: 'trip_tracking_logs',
  FuelRecord: 'fuel_records',
  Maintenance: 'maintenance_records',
  Document: 'documents',
  Location: 'locations',
  LocationPreset: 'location_presets',
  Notification: 'notifications',
  ScheduledReport: 'scheduled_reports',
  Setting: 'settings',
  AuditLog: 'audit_logs',
};

// Base44 function name (as used in base44.functions.invoke(...)) -> the
// Supabase Edge Function slug it was deployed as.
const FUNCTIONS = {
  deleteMyAccount: 'delete-my-account',
  sendTripReportEmail: 'send-trip-report-email',
  checkMaintenanceDue: 'check-maintenance-due',
  fetchFuelPrices: 'fetch-fuel-prices',
  sendScheduledReports: 'send-scheduled-reports',
};

function parseSort(sort) {
  if (!sort) return null;
  const desc = sort.startsWith('-');
  return { column: desc ? sort.slice(1) : sort, ascending: !desc };
}

function makeEntity(table) {
  return {
    // base44: Entity.list(sort, limit) — e.g. Trip.list('-started_at', 5000)
    async list(sort, limit) {
      let q = supabase.from(table).select('*');
      const s = parseSort(sort);
      if (s) q = q.order(s.column, { ascending: s.ascending });
      if (limit) q = q.limit(limit);
      const { data, error } = await q;
      if (error) throw error;
      return data;
    },
    // base44: Entity.filter({ field: value, ... }, sort, limit) — equality only;
    // nothing in this app's frontend uses operator objects like { $lte: ... }.
    async filter(query = {}, sort, limit) {
      let q = supabase.from(table).select('*');
      for (const [key, value] of Object.entries(query)) q = q.eq(key, value);
      const s = parseSort(sort);
      if (s) q = q.order(s.column, { ascending: s.ascending });
      if (limit) q = q.limit(limit);
      const { data, error } = await q;
      if (error) throw error;
      return data;
    },
    async get(id) {
      const { data, error } = await supabase.from(table).select('*').eq('id', id).single();
      if (error) throw error;
      return data;
    },
    async create(payload) {
      const { data, error } = await supabase.from(table).insert(payload).select().single();
      if (error) throw error;
      return data;
    },
    async bulkCreate(payloads) {
      const { data, error } = await supabase.from(table).insert(payloads).select();
      if (error) throw error;
      return data;
    },
    async update(id, payload) {
      const { data, error } = await supabase.from(table).update(payload).eq('id', id).select().single();
      if (error) throw error;
      return data;
    },
    async delete(id) {
      const { error } = await supabase.from(table).delete().eq('id', id);
      if (error) throw error;
      return { success: true };
    },
    async deleteMany(query = {}) {
      let q = supabase.from(table).delete();
      for (const [key, value] of Object.entries(query)) q = q.eq(key, value);
      const { error } = await q;
      if (error) throw error;
      return { success: true };
    },
  };
}

const entities = Object.fromEntries(
  Object.entries(TABLES).map(([name, table]) => [name, makeEntity(table)]),
);

async function currentUserOrThrow() {
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) {
    const err = new Error('Unauthorized');
    err.status = 401;
    throw err;
  }
  const { data: profile } = await supabase.from('profiles').select('role, full_name').eq('id', user.id).single();
  return {
    id: user.id,
    email: user.email,
    full_name: profile?.full_name ?? user.user_metadata?.full_name ?? null,
    role: profile?.role ?? 'user',
  };
}

export const base44 = {
  entities,

  auth: {
    // base44.auth.me()
    me: currentUserOrThrow,

    // base44.auth.logout(redirectUrl?)
    async logout(redirectTo) {
      await supabase.auth.signOut();
      if (redirectTo) window.location.href = redirectTo;
    },

    // base44.auth.redirectToLogin(returnUrl)
    redirectToLogin(returnUrl) {
      const target = returnUrl ? `/login?from_url=${encodeURIComponent(returnUrl)}` : '/login';
      window.location.href = target;
    },

    // base44.auth.loginViaEmailPassword(email, password)
    async loginViaEmailPassword(email, password) {
      const { error } = await supabase.auth.signInWithPassword({ email, password });
      if (error) throw error;
    },

    // base44.auth.loginWithProvider('google', redirectPath)
    async loginWithProvider(provider, redirectPath = '/') {
      const { error } = await supabase.auth.signInWithOAuth({
        provider,
        options: { redirectTo: `${window.location.origin}${redirectPath}` },
      });
      if (error) throw error;
    },

    // base44.auth.register({ email, password })
    // Triggers Supabase's own confirmation email. In the Supabase dashboard,
    // Authentication -> Email Templates, use the "Confirm signup" template's
    // {{ .Token }} (a 6-digit OTP) rather than {{ .ConfirmationURL }} so the
    // OTP-entry step below (verifyOtp) has something to check against.
    async register({ email, password }) {
      const { error } = await supabase.auth.signUp({ email, password });
      if (error) throw error;
    },

    // base44.auth.verifyOtp({ email, otpCode })
    async verifyOtp({ email, otpCode }) {
      const { data, error } = await supabase.auth.verifyOtp({ email, token: otpCode, type: 'signup' });
      if (error) throw error;
      return { access_token: data.session?.access_token };
    },

    // base44.auth.resendOtp(email)
    async resendOtp(email) {
      const { error } = await supabase.auth.resend({ type: 'signup', email });
      if (error) throw error;
    },

    // base44.auth.setToken(access_token) — no-op here: verifyOtp() above
    // already leaves supabase-js holding the new session. Kept only so
    // Register.jsx doesn't need to change.
    setToken() {},

    // base44.auth.resetPasswordRequest(email)
    async resetPasswordRequest(email) {
      const { error } = await supabase.auth.resetPasswordForEmail(email, {
        redirectTo: `${window.location.origin}/reset-password`,
      });
      if (error) throw error;
    },

    // base44.auth.resetPassword({ resetToken, newPassword })
    // NOTE — the one real behavioural difference in this file: Base44 passed
    // a resetToken your ResetPassword page read from the URL. Supabase's
    // reset-password link instead logs the browser straight into a session
    // when it's opened, so `resetToken` is ignored here and the new password
    // is just set on that session. If src/pages/ResetPassword.jsx reads a
    // token out of the URL and blocks on it being present, that check needs
    // to come out — see the migration guide, phase on Auth.
    async resetPassword({ newPassword }) {
      const { error } = await supabase.auth.updateUser({ password: newPassword });
      if (error) throw error;
    },
  },

  functions: {
    // base44.functions.invoke('deleteMyAccount', {...})
    async invoke(name, body = {}) {
      const slug = FUNCTIONS[name] || name;
      const { data, error } = await supabase.functions.invoke(slug, { body });
      if (error) throw error;
      return data;
    },
  },

  integrations: {
    Core: {
      // base44.integrations.Core.UploadFile({ file }) -> { file_url }
      async UploadFile({ file }) {
        const path = `${crypto.randomUUID()}-${file.name}`;
        const { error } = await supabase.storage.from('kannaz-uploads').upload(path, file);
        if (error) throw error;
        const { data } = supabase.storage.from('kannaz-uploads').getPublicUrl(path);
        return { file_url: data.publicUrl };
      },
    },
  },
};
