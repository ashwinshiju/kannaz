# KANNAZ → Supabase migration kit

Generated from the complete Base44 export (`kannaz 2.zip`) — real entity
schemas (`base44/entities/*.jsonc`), real backend functions
(`base44/functions/*/entry.ts`), and real workflow schedules
(`base44/workflows/*.jsonc`). Companion to the full write-up: see the
"Leaving Base44" guide artifact for the narrative walkthrough this kit plugs
into.

## What's in here

- **`schema.sql`** — every table (15, matching each `base44/entities/*.jsonc`),
  Row Level Security policies translated from each entity's embedded `rls`
  block, and the storage bucket for uploads. Run once, top to bottom, in the
  Supabase SQL editor on a fresh project.
- **`cron.sql`** — recreates the 3 `base44/workflows/*.jsonc` schedules as
  Supabase Cron jobs. Run after the functions below are deployed.
- **`functions/`** — the 5 `base44/functions/*/entry.ts` backend functions,
  ported to Supabase Edge Functions (both run on Deno, so the logic itself
  barely changed — only the Base44 SDK calls became Supabase client calls).
- **`frontend/base44Client.js`** — drop-in replacement for
  `src/api/base44Client.js`. Keeps the same `base44.entities` /
  `base44.auth` / `base44.functions` / `base44.integrations.Core.UploadFile`
  surface every page already imports, backed by Supabase instead.
- **`frontend/.env.example`** — the env vars that replace `VITE_BASE44_*`.

## Order of operations

1. Create a Supabase project, then run `schema.sql` in its SQL editor.
2. Deploy the functions (from this `functions/` directory, inside your
   Supabase project's `supabase/` folder — or point the CLI at this path):
   ```
   supabase functions deploy check-maintenance-due --no-verify-jwt
   supabase functions deploy fetch-fuel-prices --no-verify-jwt
   supabase functions deploy send-scheduled-reports --no-verify-jwt
   supabase functions deploy send-trip-report-email
   supabase functions deploy delete-my-account
   ```
3. Set secrets the functions need:
   ```
   supabase secrets set RESEND_API_KEY=re_xxx RESEND_FROM="Kannaz <reports@yourdomain.com>"
   ```
   (`SUPABASE_URL` and `SUPABASE_SERVICE_ROLE_KEY` are injected automatically.)
4. Edit `cron.sql` — fill in your project ref and service role key — then run
   it in the SQL editor.
5. In Authentication -> Providers, turn on Email and Google. In
   Authentication -> Email Templates, switch "Confirm signup" to send an OTP
   code rather than a magic link (KANNAZ's Register page expects a 6-digit
   code, per `base44.auth.verifyOtp`).
6. Copy `frontend/base44Client.js` over `src/api/base44Client.js` in the app,
   copy `.env.example` to `.env.local` and fill in your project's URL/anon
   key, `npm install @supabase/supabase-js`, remove `@base44/sdk` /
   `@base44/vite-plugin`.
7. Copy `frontend/ResetPassword.jsx` over `src/pages/ResetPassword.jsx` — the
   one page that needs an actual edit, not just the client swap (see the
   comment at the top of the file for why).
8. Delete `src/pages/OAuthConsent.jsx` and its (already absent) route, unless
   you're deliberately using Base44's MCP/AI-client-connector feature. It
   calls Base44 platform endpoints directly (`/api/apps/.../mcp/...`) that
   won't exist once you're off Base44, it isn't wired into `App.jsx`'s
   router in this export, and there's no `base44/mcp/` config in the project
   — so it's currently unused dead code, safe to remove. If you *do* use
   that feature, it needs its own OAuth authorization server; that's outside
   what this kit covers.
9. Migrate existing data/files (Base44 CSV export -> Supabase import; see the
   guide's data-migration phase) before pointing real users at this.

Everything here is a generated starting point from your actual schema and
functions — read it before trusting it with production data, especially the
RLS policies in `schema.sql`.
