-- KANNAZ: recreate the 3 Base44 workflows (base44/workflows/*.jsonc) as
-- Supabase Cron jobs that call the matching Edge Function over HTTP.
-- Run this after `supabase functions deploy` has deployed all 5 functions.
--
-- pg_cron runs in UTC. Asia/Dubai is UTC+4 with no daylight saving, so every
-- time below is the original Asia/Dubai schedule minus 4 hours. If your
-- Supabase project's Cron dashboard (Database -> Cron) offers a timezone
-- picker, you can enter the original Asia/Dubai expression there instead of
-- doing the conversion by hand.
--
-- Replace <project-ref> and <SERVICE_ROLE_KEY> below (Project Settings ->
-- API). Keep the service role key here — this file lives in your own
-- Supabase project's SQL editor, not in the frontend.

create extension if not exists pg_cron;
create extension if not exists pg_net;

-- 1) Maintenance Due Check — originally daily at 09:00 Asia/Dubai -> 05:00 UTC
select cron.schedule(
  'check-maintenance-due',
  '0 5 * * *',
  $$
  select net.http_post(
    url := 'https://<project-ref>.supabase.co/functions/v1/check-maintenance-due',
    headers := jsonb_build_object('Content-Type', 'application/json', 'Authorization', 'Bearer <SERVICE_ROLE_KEY>'),
    body := '{}'::jsonb,
    timeout_milliseconds := 20000
  ) as request_id;
  $$
);

-- 2) Scheduled Report Email — every 15 minutes, unchanged (no timezone-sensitive fields)
select cron.schedule(
  'send-scheduled-reports',
  '*/15 * * * *',
  $$
  select net.http_post(
    url := 'https://<project-ref>.supabase.co/functions/v1/send-scheduled-reports',
    headers := jsonb_build_object('Content-Type', 'application/json', 'Authorization', 'Bearer <SERVICE_ROLE_KEY>'),
    body := '{}'::jsonb,
    timeout_milliseconds := 20000
  ) as request_id;
  $$
);

-- 3) Monthly Fuel Price Sync — originally 1st of the month, 02:00 Asia/Dubai.
--    Expressed in UTC that's 22:00 on the *last day of the previous month*,
--    which a plain 5-field cron expression can't say directly. This runs it
--    at 22:00 UTC on the 1st instead — i.e. ~2am Dubai time on the 2nd, one
--    day later than the original. Good enough for a monthly price sync; if
--    exact-day timing matters, add a day-of-month guard inside
--    functions/fetch-fuel-prices/index.ts instead and switch this to a daily
--    schedule.
select cron.schedule(
  'fetch-fuel-prices',
  '0 22 1 * *',
  $$
  select net.http_post(
    url := 'https://<project-ref>.supabase.co/functions/v1/fetch-fuel-prices',
    headers := jsonb_build_object('Content-Type', 'application/json', 'Authorization', 'Bearer <SERVICE_ROLE_KEY>'),
    body := '{}'::jsonb,
    timeout_milliseconds := 20000
  ) as request_id;
  $$
);

-- Useful while testing:
--   select * from cron.job;               -- see what's scheduled
--   select * from cron.job_run_details order by start_time desc limit 20;
--   select cron.unschedule('check-maintenance-due');  -- remove a job
