-- KANNAZ: Base44 -> Supabase schema
-- Generated from base44/entities/*.jsonc (field lists + embedded RLS rules).
-- Review before running against production data. Run in the Supabase SQL editor,
-- top to bottom, on a fresh project.

-- ============================================================================
-- 0. Extensions & helpers
-- ============================================================================
create extension if not exists pgcrypto;   -- gen_random_uuid()
create extension if not exists pg_net;     -- needed later for cron.sql (http calls)

-- Base44's own "User" entity is just { role: admin | user }, layered on top of
-- its auth system. Supabase Auth owns identity (auth.users); this table adds
-- the one field Base44's RLS rules actually check: role.
create table public.profiles (
  id         uuid primary key references auth.users(id) on delete cascade,
  email      text,
  full_name  text,
  role       text not null default 'user' check (role in ('admin','user')),
  created_at timestamptz not null default now()
);

-- Auto-create a profile row whenever someone signs up via Supabase Auth.
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer as $$
begin
  insert into public.profiles (id, email, full_name)
  values (new.id, new.email, new.raw_user_meta_data->>'full_name');
  return new;
end;
$$;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

create or replace function public.is_admin()
returns boolean language sql stable as $$
  select exists (select 1 from public.profiles where id = auth.uid() and role = 'admin');
$$;

-- Every Base44 entity carries these implicitly; every table below gets them too.
--   id            uuid primary key
--   created_date  timestamptz  (Base44's own row-creation timestamp)
--   updated_date  timestamptz
--   created_by_id uuid         (the row's owner — what Base44's RLS calls {{user.id}})

-- ============================================================================
-- 1. Reference tables
-- ============================================================================

create table public.departments (
  id             uuid primary key default gen_random_uuid(),
  name           text not null,
  code           text not null,
  manager_name   text,
  description    text,
  status         text not null default 'active' check (status in ('active','inactive')),
  created_date   timestamptz not null default now(),
  updated_date   timestamptz not null default now(),
  created_by_id  uuid references auth.users(id) default auth.uid()
);

create table public.employees (
  id                  uuid primary key default gen_random_uuid(),
  emp_id              text not null,
  full_name           text not null,
  email               text not null,
  mobile              text,
  department          text,
  designation         text,
  manager_id          uuid references public.employees(id),
  default_vehicle_id  uuid,
  role                text not null default 'employee' check (role in ('admin','manager','employee')),
  status              text not null default 'active' check (status in ('active','disabled')),
  avatar_url          text,
  created_date        timestamptz not null default now(),
  updated_date        timestamptz not null default now(),
  created_by_id       uuid references auth.users(id) default auth.uid()
);
create unique index employees_email_idx on public.employees (lower(email));

create table public.vehicles (
  id                    uuid primary key default gen_random_uuid(),
  reg_no                text not null,
  name                  text not null,
  make                  text not null,
  model                 text not null,
  year                  numeric,
  color                 text,
  fuel_type             text check (fuel_type in ('petrol','diesel','electric','hybrid','cng')),
  assigned_department   text,
  current_odometer      numeric default 0,
  insurance_expiry      date,
  registration_expiry   date,
  status                text not null default 'available'
                          check (status in ('available','in_use','maintenance','inactive','reserved')),
  image_url             text,
  created_date          timestamptz not null default now(),
  updated_date          timestamptz not null default now(),
  created_by_id         uuid references auth.users(id) default auth.uid()
);

alter table public.employees
  add constraint employees_default_vehicle_fk foreign key (default_vehicle_id) references public.vehicles(id);

create table public.locations (
  id             uuid primary key default gen_random_uuid(),
  name           text not null,
  category       text not null check (category in ('office','customer','warehouse','public','other')),
  address        text not null,
  latitude       numeric,
  longitude      numeric,
  description    text,
  status         text not null default 'active' check (status in ('active','inactive')),
  is_favorite    boolean not null default false,
  created_date   timestamptz not null default now(),
  updated_date   timestamptz not null default now(),
  created_by_id  uuid references auth.users(id) default auth.uid()
);

create table public.location_presets (
  id             uuid primary key default gen_random_uuid(),
  name           text not null,
  category       text not null default 'office' check (category in ('office','warehouse','public','customer','other')),
  latitude       numeric not null,
  longitude      numeric not null,
  radius         numeric not null default 100,
  created_date   timestamptz not null default now(),
  updated_date   timestamptz not null default now(),
  created_by_id  uuid references auth.users(id) default auth.uid()
);

create table public.settings (
  id             uuid primary key default gen_random_uuid(),
  key            text not null,
  value          text not null,
  category       text not null check (category in ('company','trip','notification','security','system')),
  description    text,
  created_date   timestamptz not null default now(),
  updated_date   timestamptz not null default now(),
  created_by_id  uuid references auth.users(id) default auth.uid()
);
create unique index settings_key_idx on public.settings (key);

-- ============================================================================
-- 2. Operational tables
-- ============================================================================

create table public.trips (
  id                          uuid primary key default gen_random_uuid(),
  trip_number                 text,
  employee_id                 uuid references public.employees(id),
  employee_name               text not null,
  employee_ref_id             text,
  employee_unlinked           boolean not null default false,
  vehicle_id                  uuid references public.vehicles(id),
  vehicle_name                text not null,
  department                  text,
  start_location               text not null,
  end_location                 text not null,
  start_location_preset_id    uuid references public.location_presets(id),
  end_location_preset_id      uuid references public.location_presets(id),
  start_lat                   numeric,
  start_lng                   numeric,
  end_lat                     numeric,
  end_lng                     numeric,
  start_trust_score           numeric,
  start_gps_metadata          text,
  end_trust_score             numeric,
  end_gps_metadata            text,
  odometer_manually_entered   boolean not null default false,
  purpose                     text not null default 'official' check (purpose in ('official','personal','maintenance')),
  status                      text not null default 'created'
                                check (status in ('created','in_progress','completed','acknowledged','cancelled')),
  start_odometer               numeric,
  end_odometer                 numeric,
  distance_km                  numeric,
  tracked_distance_km          numeric,
  low_tracking_data            boolean not null default false,
  tracking_gaps                text,
  tracking_gap_count           numeric,
  raw_points_captured          numeric,
  valid_points_count           numeric,
  discarded_jump_count         numeric,
  discarded_low_trust_count    numeric,
  discarded_spoofed_count      numeric,
  distance_mismatch            boolean not null default false,
  duration_minutes             numeric,
  started_at                   timestamptz,
  completed_at                 timestamptz,
  acknowledged_at              timestamptz,
  acknowledged_by              text,
  notes                        text,
  manager_id                   uuid,
  created_date                 timestamptz not null default now(),
  updated_date                 timestamptz not null default now(),
  created_by_id                uuid references auth.users(id) default auth.uid()
);
create index trips_started_at_idx on public.trips (started_at desc);
create index trips_completed_at_idx on public.trips (completed_at desc);
create index trips_vehicle_idx on public.trips (vehicle_id);
create index trips_employee_idx on public.trips (employee_id);

create table public.trip_tracking_logs (
  id             uuid primary key default gen_random_uuid(),
  trip_id        uuid not null references public.trips(id) on delete cascade,
  latitude       numeric not null,
  longitude      numeric not null,
  timestamp_ms   bigint,
  speed_kmh      numeric,
  trust_score    numeric,
  gps_metadata   text,
  is_valid       boolean not null default true,
  created_date   timestamptz not null default now(),
  updated_date   timestamptz not null default now(),
  created_by_id  uuid references auth.users(id) default auth.uid()
);
create index trip_tracking_logs_trip_idx on public.trip_tracking_logs (trip_id);

create table public.fuel_records (
  id                 uuid primary key default gen_random_uuid(),
  vehicle_id         uuid references public.vehicles(id),
  vehicle_name       text not null,
  employee_id        uuid references public.employees(id),
  employee_name      text,
  fuel_date          date not null,
  station            text,
  fuel_type          text check (fuel_type in ('super_98','special_95','eplus_91','diesel')),
  fuel_rate          numeric,
  litres             numeric not null,
  cost               numeric not null,
  odometer           numeric,
  efficiency_kmpl     numeric,
  receipt_url        text,
  created_date       timestamptz not null default now(),
  updated_date       timestamptz not null default now(),
  created_by_id      uuid references auth.users(id) default auth.uid()
);

create table public.maintenance_records (
  id                       uuid primary key default gen_random_uuid(),
  vehicle_id               uuid references public.vehicles(id),
  vehicle_name             text not null,
  service_type             text not null check (service_type in
                              ('oil_change','brakes','tires','battery','engine','transmission','general','inspection','other')),
  description              text,
  cost                     numeric,
  scheduled_date           date,
  completed_date           date,
  odometer                 numeric,
  next_service_odometer    numeric,
  vendor                   text,
  invoice_url              text,
  status                   text not null default 'scheduled'
                              check (status in ('scheduled','in_progress','completed','cancelled')),
  created_date             timestamptz not null default now(),
  updated_date             timestamptz not null default now(),
  created_by_id            uuid references auth.users(id) default auth.uid()
);

create table public.documents (
  id             uuid primary key default gen_random_uuid(),
  vehicle_id     uuid references public.vehicles(id),
  vehicle_name   text not null,
  doc_type       text check (doc_type in
                    ('insurance','registration','tire_certificate','battery_warranty','emission_test','fitness_certificate','other')),
  doc_number     text,
  issuer         text,
  issue_date     date,
  expiry_date    date,
  file_url       text,
  status         text not null default 'valid' check (status in ('valid','expiring_soon','expired')),
  notes          text,
  created_date   timestamptz not null default now(),
  updated_date   timestamptz not null default now(),
  created_by_id  uuid references auth.users(id) default auth.uid()
);

create table public.notifications (
  id               uuid primary key default gen_random_uuid(),
  title            text not null,
  message          text not null,
  type             text not null check (type in ('info','warning','error','success','trip','maintenance','document')),
  target_user_id   uuid references auth.users(id),
  is_read          boolean not null default false,
  link             text,
  created_date     timestamptz not null default now(),
  updated_date     timestamptz not null default now(),
  created_by_id    uuid references auth.users(id) default auth.uid()
);

create table public.scheduled_reports (
  id                  uuid primary key default gen_random_uuid(),
  recipient_email     text not null,
  week_start_iso      text not null,
  week_end_iso        text not null,
  week_label          text not null,
  scheduled_send_at   timestamptz not null,
  status              text not null default 'pending' check (status in ('pending','sent','failed')),
  sent_at             timestamptz,
  error_message       text,
  created_date        timestamptz not null default now(),
  updated_date        timestamptz not null default now(),
  created_by_id       uuid references auth.users(id) default auth.uid()
);

create table public.audit_logs (
  id             uuid primary key default gen_random_uuid(),
  user_name      text not null,
  user_email     text,
  action         text not null check (action in ('login','logout','create','update','delete','view','export','settings_change')),
  module         text not null,
  entity_type    text,
  entity_id      text,
  details        text,
  ip_address     text,
  created_date   timestamptz not null default now(),
  updated_date   timestamptz not null default now(),
  created_by_id  uuid references auth.users(id) default auth.uid()
);

-- ============================================================================
-- 3. Row Level Security — translated from each entity's "rls" block
--    Pattern key:
--      ADMIN_ONLY   -> user_condition: { role: admin }
--      OPEN         -> null (any authenticated user)
--      OWNER_ADMIN  -> $or [ created_by_id = {{user.id}}, role admin ]
--      Custom       -> noted inline (Notification, ScheduledReport)
-- ============================================================================

alter table public.profiles              enable row level security;
alter table public.departments           enable row level security;
alter table public.employees             enable row level security;
alter table public.vehicles              enable row level security;
alter table public.locations             enable row level security;
alter table public.location_presets      enable row level security;
alter table public.settings              enable row level security;
alter table public.trips                 enable row level security;
alter table public.trip_tracking_logs    enable row level security;
alter table public.fuel_records          enable row level security;
alter table public.maintenance_records   enable row level security;
alter table public.documents             enable row level security;
alter table public.notifications         enable row level security;
alter table public.scheduled_reports     enable row level security;
alter table public.audit_logs            enable row level security;

-- profiles: everyone can read (needed for admin checks/joins); only the
-- platform (service role) changes roles — no end-user policy for writes.
create policy profiles_read on public.profiles for select using (true);

-- departments: ADMIN_ONLY create/update/delete, OPEN read
create policy departments_read   on public.departments for select using (true);
create policy departments_write  on public.departments for insert with check (is_admin());
create policy departments_update on public.departments for update using (is_admin());
create policy departments_delete on public.departments for delete using (is_admin());

-- employees: ADMIN_ONLY create/update/delete, OPEN read
create policy employees_read   on public.employees for select using (true);
create policy employees_write  on public.employees for insert with check (is_admin());
create policy employees_update on public.employees for update using (is_admin());
create policy employees_delete on public.employees for delete using (is_admin());

-- vehicles: ADMIN_ONLY create/delete, OPEN read + update (any signed-in user
-- updates odometer/status when ending a trip)
create policy vehicles_read   on public.vehicles for select using (true);
create policy vehicles_write  on public.vehicles for insert with check (is_admin());
create policy vehicles_update on public.vehicles for update using (true);
create policy vehicles_delete on public.vehicles for delete using (is_admin());

-- locations: ADMIN_ONLY create, OPEN read, OWNER_ADMIN update/delete
create policy locations_read   on public.locations for select using (true);
create policy locations_write  on public.locations for insert with check (is_admin());
create policy locations_update on public.locations for update using (created_by_id = auth.uid() or is_admin());
create policy locations_delete on public.locations for delete using (created_by_id = auth.uid() or is_admin());

-- location_presets: same shape as locations
create policy presets_read   on public.location_presets for select using (true);
create policy presets_write  on public.location_presets for insert with check (is_admin());
create policy presets_update on public.location_presets for update using (created_by_id = auth.uid() or is_admin());
create policy presets_delete on public.location_presets for delete using (created_by_id = auth.uid() or is_admin());

-- settings: ADMIN_ONLY create/update/delete, OPEN read
create policy settings_read   on public.settings for select using (true);
create policy settings_write  on public.settings for insert with check (is_admin());
create policy settings_update on public.settings for update using (is_admin());
create policy settings_delete on public.settings for delete using (is_admin());

-- trips: OPEN create, OPEN read, OWNER_ADMIN update/delete
create policy trips_read   on public.trips for select using (true);
create policy trips_write  on public.trips for insert with check (true);
create policy trips_update on public.trips for update using (created_by_id = auth.uid() or is_admin());
create policy trips_delete on public.trips for delete using (created_by_id = auth.uid() or is_admin());

-- trip_tracking_logs: OPEN create, OPEN read, OWNER_ADMIN update/delete
create policy ttl_read   on public.trip_tracking_logs for select using (true);
create policy ttl_write  on public.trip_tracking_logs for insert with check (true);
create policy ttl_update on public.trip_tracking_logs for update using (created_by_id = auth.uid() or is_admin());
create policy ttl_delete on public.trip_tracking_logs for delete using (created_by_id = auth.uid() or is_admin());

-- fuel_records: OPEN create, OPEN read, OWNER_ADMIN update/delete
create policy fuel_read   on public.fuel_records for select using (true);
create policy fuel_write  on public.fuel_records for insert with check (true);
create policy fuel_update on public.fuel_records for update using (created_by_id = auth.uid() or is_admin());
create policy fuel_delete on public.fuel_records for delete using (created_by_id = auth.uid() or is_admin());

-- maintenance_records: ADMIN_ONLY create, OPEN read, OWNER_ADMIN update/delete
create policy maint_read   on public.maintenance_records for select using (true);
create policy maint_write  on public.maintenance_records for insert with check (is_admin());
create policy maint_update on public.maintenance_records for update using (created_by_id = auth.uid() or is_admin());
create policy maint_delete on public.maintenance_records for delete using (created_by_id = auth.uid() or is_admin());

-- documents: ADMIN_ONLY create, OPEN read, OWNER_ADMIN update/delete
create policy docs_read   on public.documents for select using (true);
create policy docs_write  on public.documents for insert with check (is_admin());
create policy docs_update on public.documents for update using (created_by_id = auth.uid() or is_admin());
create policy docs_delete on public.documents for delete using (created_by_id = auth.uid() or is_admin());

-- notifications: created only by the backend (service role, RLS bypassed);
-- a user reads/updates/deletes their own (target_user_id or creator), admins see all
create policy notif_read on public.notifications for select
  using (target_user_id = auth.uid() or created_by_id = auth.uid() or is_admin());
create policy notif_update on public.notifications for update
  using (target_user_id = auth.uid() or created_by_id = auth.uid() or is_admin());
create policy notif_delete on public.notifications for delete
  using (target_user_id = auth.uid() or created_by_id = auth.uid() or is_admin());

-- scheduled_reports: OWNER_ADMIN create, read also allowed for the named
-- recipient, OWNER_ADMIN update/delete
create policy sr_read on public.scheduled_reports for select
  using (recipient_email = (auth.jwt() ->> 'email') or created_by_id = auth.uid() or is_admin());
create policy sr_write on public.scheduled_reports for insert
  with check (created_by_id = auth.uid() or is_admin());
create policy sr_update on public.scheduled_reports for update
  using (created_by_id = auth.uid() or is_admin());
create policy sr_delete on public.scheduled_reports for delete
  using (created_by_id = auth.uid() or is_admin());

-- audit_logs: ADMIN_ONLY, full stop, in every direction
create policy audit_all on public.audit_logs for all using (is_admin()) with check (is_admin());

-- ============================================================================
-- 4. Storage bucket for uploads (fuel receipts, vehicle/document files)
-- ============================================================================
insert into storage.buckets (id, name, public)
values ('kannaz-uploads', 'kannaz-uploads', true)
on conflict (id) do nothing;

create policy "kannaz-uploads: authenticated write"
  on storage.objects for insert
  with check (bucket_id = 'kannaz-uploads' and auth.role() = 'authenticated');

create policy "kannaz-uploads: public read"
  on storage.objects for select
  using (bucket_id = 'kannaz-uploads');
