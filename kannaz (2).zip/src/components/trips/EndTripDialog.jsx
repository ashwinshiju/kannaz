import React, { useState, useRef, useEffect } from 'react';
import { useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { GPSService, calculateDistance } from '@/services/GPSService';
import { detectGaps, calculateGapAwareDistance, calculateDistanceMismatch } from '@/services/trackingGapAnalysis';
import { getGpsTrackingConfig } from '@/lib/configLoader';
import { findMatchingPreset } from '@/services/presetMatching';
import { MapPin, Loader2, AlertTriangle, Car, Clock } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/components/ui/use-toast';
import TripSummaryCard from '@/components/trips/TripSummaryCard';

export default function EndTripDialog({ trip, open, onClose }) {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const gpsServiceRef = useRef(null);
  const [gpsConfig, setGpsConfig] = useState(null);

  // Fetch admin-configurable GPS thresholds once on mount so the end-point
  // capture and gap-aware distance calculation use current values.
  useEffect(() => {
    getGpsTrackingConfig()
      .then((cfg) => {
        setGpsConfig(cfg);
        gpsServiceRef.current = new GPSService({
          maxAccuracyMeters: cfg.max_accuracy_meters,
          maxRealisticSpeedKmh: cfg.max_realistic_speed_kmh,
          trustPenaltyAccuracyM: cfg.trust_penalty_accuracy_m,
        });
      })
      .catch(() => setGpsConfig({}));
  }, []);

  const [endOdometer, setEndOdometer] = useState('');
  const [endLat, setEndLat] = useState('');
  const [endLng, setEndLng] = useState('');
  const [gpsMetadata, setGpsMetadata] = useState(null);
  const [gpsWarning, setGpsWarning] = useState(null);
  const [gpsCapturing, setGpsCapturing] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [odometerError, setOdometerError] = useState(null);
  const [notes, setNotes] = useState('');
  const [endPresetId, setEndPresetId] = useState(null);
  const [postTripChoice, setPostTripChoice] = useState('');

  // Reset all state when the dialog opens for a new trip.
  useEffect(() => {
    if (open) {
      setEndOdometer('');
      setEndLat('');
      setEndLng('');
      setGpsMetadata(null);
      setGpsWarning(null);
      setGpsCapturing(false);
      setSubmitting(false);
      setOdometerError(null);
      setNotes('');
      setEndPresetId(null);
      setPostTripChoice('');
    }
  }, [open, trip?.id]);

  // Auto-capture GPS when the dialog opens — the user only needs to enter the
  // final odometer reading.
  useEffect(() => {
    if (open && !gpsCapturing && !gpsMetadata) {
      handleCaptureGPS();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, trip?.id]);

  const startOdo = trip?.start_odometer;

  const validateOdometer = (val) => {
    if (val === '' || val == null) {
      setOdometerError('End odometer is required');
      return false;
    }
    const num = parseFloat(val);
    if (isNaN(num)) {
      setOdometerError('End odometer must be a valid number');
      return false;
    }
    if (startOdo != null && num < startOdo) {
      setOdometerError(`End odometer (${num} km) must be ≥ start odometer (${startOdo} km)`);
      return false;
    }
    setOdometerError(null);
    return true;
  };

  const handleOdometerChange = (e) => {
    const val = e.target.value;
    setEndOdometer(val);
    if (odometerError) validateOdometer(val);
  };

  const handleCaptureGPS = async () => {
    setGpsCapturing(true);
    setGpsWarning(null);
    setGpsMetadata(null);

    // Reuse the same GPSService.captureSinglePoint used on Start Trip —
    // no new/duplicate GPS logic.
    const result = await gpsServiceRef.current.captureSinglePoint();

    if (result.error || !result.point) {
      setGpsWarning(result.error || 'Failed to capture GPS coordinates');
      setGpsCapturing(false);
      return;
    }

    const point = result.point;
    setEndLat(point.lat.toFixed(6));
    setEndLng(point.lng.toFixed(6));
    setGpsMetadata({
      trustScore: point.trustScore,
      confidence: point.confidence,
      accuracy: point.accuracy,
      isMocked: point.isMocked,
      spoofed: point.spoofed,
      spoofReasons: point.spoofReasons,
      isJump: point.isJump,
      timestamp: point.timestamp,
    });

    if (point.confidence === 'low' || point.isMocked || point.spoofed || point.isJump) {
      const reasons = [];
      if (point.confidence === 'low') reasons.push(`Low accuracy (${point.accuracy != null ? Math.round(point.accuracy) : '?'}m)`);
      if (point.isMocked) reasons.push('Mocked location flag detected');
      if (point.spoofed) reasons.push(`Spoofing detected: ${(point.spoofReasons || []).join(', ')}`);
      if (point.isJump) reasons.push('GPS jump anomaly detected');
      setGpsWarning(`GPS reading flagged (trust score: ${point.trustScore}/100) — ${reasons.join('; ')}`);
    }

    // Match captured coordinates against saved LocationPresets (Haversine).
    const matchedPreset = await findMatchingPreset(point.lat, point.lng);
    setEndPresetId(matchedPreset?.id || null);

    setGpsCapturing(false);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!validateOdometer(endOdometer)) return;
    if (!endLat || !endLng) {
      toast({ title: 'Please capture end GPS coordinates', variant: 'destructive' });
      return;
    }
    if (!postTripChoice) {
      toast({ title: 'Please choose what happens to the vehicle after the trip', variant: 'destructive' });
      return;
    }

    setSubmitting(true);

    try {
      const endOdoNum = parseFloat(endOdometer);
      const distance = startOdo != null ? Math.round((endOdoNum - startOdo) * 100) / 100 : null;

      // Calculate tracked distance from the GPS trail (TripTrackingLog points
      // persisted every ~15s during the trip). Uses gap-aware analysis:
      // detects time gaps >2.5× the expected interval, estimates missing
      // distance via speed interpolation, and flags incomplete segments.
      // Reuses GPSService's Haversine — no new distance logic.
      let trackedDistanceKm = null;
      let lowTrackingData = false;
      let trackingGaps = [];
      let trackingGapCount = 0;
      let hasIncompleteGaps = false;
      let rawPointsCaptured = 0;
      let validPointsCount = 0;
      let discardedJumpCount = 0;
      let discardedLowTrustCount = 0;
      let discardedSpoofedCount = 0;
      const endLatNum = parseFloat(endLat);
      const endLngNum = parseFloat(endLng);

      try {
        const logPoints = await base44.entities.TripTrackingLog.filter(
          { trip_id: trip.id },
          'timestamp_ms',
          500
        );
        const sortedPoints = logPoints.sort(
          (a, b) => (a.timestamp_ms || 0) - (b.timestamp_ms || 0)
        );
        rawPointsCaptured = sortedPoints.length;

        // Filter out invalid points (trust score below threshold, or
        // anomaly/spoofed flag true) so bad readings don't inflate distance.
        const validPoints = sortedPoints.filter((p) => p.is_valid !== false);
        validPointsCount = validPoints.length;

        // Per-trip discard breakdown: categorize each invalid point by the
        // filter that caused its rejection. Priority: spoofing > jump > low
        // trust — so the three counts sum to total discarded. Each point's
        // rejection reason is read from its persisted gps_metadata JSON.
        const invalidPoints = sortedPoints.filter((p) => p.is_valid === false);
        for (const p of invalidPoints) {
          let meta = {};
          try {
            meta = typeof p.gps_metadata === 'string'
              ? JSON.parse(p.gps_metadata || '{}')
              : (p.gps_metadata || {});
          } catch { /* treat as empty */ }
          if (meta.spoofed || meta.isMocked) {
            discardedSpoofedCount++;
          } else if (meta.isJump) {
            discardedJumpCount++;
          } else {
            discardedLowTrustCount++;
          }
        }

        if (validPoints.length >= 2) {
          // Detect tracking gaps — segments where time between consecutive
          // points exceeds 2.5× the expected interval.
          const { gaps } = detectGaps(validPoints, gpsConfig || {});
          trackingGapCount = gaps.length;

          // Calculate distance with gap awareness: continuous segments use
          // Haversine; gap segments use speed interpolation when available,
          // otherwise are excluded and flagged as incomplete.
          const result = calculateGapAwareDistance(validPoints, gaps, gpsConfig || {});
          trackedDistanceKm = result.trackedDistanceKm;
          trackingGaps = result.gapDetails;
          hasIncompleteGaps = result.hasIncompleteGaps;

          if (hasIncompleteGaps) {
            lowTrackingData = true;
          }
        } else {
          // Fewer than 2 valid tracked points — fall back to Haversine
          // between start and end coordinates, flag as low tracking data.
          lowTrackingData = true;
          if (trip.start_lat != null && trip.start_lng != null) {
            const fallbackMeters = calculateDistance(
              trip.start_lat, trip.start_lng,
              endLatNum, endLngNum
            );
            trackedDistanceKm = Math.round((fallbackMeters / 1000) * 100) / 100;
          }
        }
      } catch {
        // Point retrieval failed — fall back to start/end Haversine.
        lowTrackingData = true;
        if (trip.start_lat != null && trip.start_lng != null) {
          const fallbackMeters = calculateDistance(
            trip.start_lat, trip.start_lng,
            endLatNum, endLngNum
          );
          trackedDistanceKm = Math.round((fallbackMeters / 1000) * 100) / 100;
        }
      }

      // Calculate discrepancy between tracked and odometer distance.
      const mismatchResult = calculateDistanceMismatch(trackedDistanceKm, distance, gpsConfig || {});

      const updates = {
        status: 'completed',
        completed_at: new Date().toISOString(),
        end_odometer: endOdoNum,
        end_lat: endLatNum,
        end_lng: endLngNum,
        end_trust_score: gpsMetadata?.trustScore ?? null,
        end_gps_metadata: gpsMetadata ? JSON.stringify(gpsMetadata) : '',
        end_location: `GPS: ${endLatNum.toFixed(6)}, ${endLngNum.toFixed(6)}`,
        distance_km: distance,
        tracked_distance_km: trackedDistanceKm,
        low_tracking_data: lowTrackingData,
        tracking_gaps: trackingGaps.length > 0 ? JSON.stringify(trackingGaps) : '',
        tracking_gap_count: trackingGapCount,
        raw_points_captured: rawPointsCaptured,
        valid_points_count: validPointsCount,
        discarded_jump_count: discardedJumpCount,
        discarded_low_trust_count: discardedLowTrustCount,
        discarded_spoofed_count: discardedSpoofedCount,
        distance_mismatch: mismatchResult.mismatch,
        notes: notes || '',
        end_location_preset_id: endPresetId || '',
      };

      await base44.entities.Trip.update(trip.id, updates);

      // Update the vehicle's current_odometer so the next trip's start
      // odometer auto-fills from this value, and revert status to available.
      if (trip.vehicle_id) {
        await base44.entities.Vehicle.update(trip.vehicle_id, {
          current_odometer: endOdoNum,
          status: postTripChoice === 'keep' ? 'reserved' : 'available',
        });
      }

      queryClient.invalidateQueries({ queryKey: ['trips'] });
      queryClient.invalidateQueries({ queryKey: ['vehicles'] });
      queryClient.invalidateQueries({ queryKey: ['vehicles', 'available'] });

      toast({ title: 'Trip completed successfully' });
      onClose(false);
    } catch (error) {
      toast({
        title: 'Failed to complete trip',
        description: error.message || 'An unexpected error occurred',
        variant: 'destructive',
      });
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-lg max-h-[85vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>End trip</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-5 py-2">
          {/* Start odometer (read-only context) */}
          <div className="space-y-1.5">
            <Label>Start odometer (km)</Label>
            <Input
              type="text"
              value={startOdo != null ? String(startOdo) : '—'}
              readOnly
              className="bg-muted/50"
            />
          </div>

          {/* End odometer (manual entry required) */}
          <div className="space-y-1.5">
            <Label htmlFor="end_odometer">
              End odometer (km)
              <span className="text-destructive ml-0.5">*</span>
            </Label>
            <Input
              id="end_odometer"
              type="number"
              step="0.01"
              value={endOdometer}
              onChange={handleOdometerChange}
              onBlur={(e) => validateOdometer(e.target.value)}
              placeholder="Enter final odometer reading"
              required
            />
            {odometerError && (
              <p className="text-xs text-destructive flex items-center gap-1">
                <AlertTriangle className="w-3 h-3" />
                {odometerError}
              </p>
            )}
          </div>

          {/* GPS capture */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <Label>
                End location (GPS)
                <span className="text-destructive ml-0.5">*</span>
              </Label>
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={handleCaptureGPS}
                disabled={gpsCapturing}
                className="gap-1.5"
              >
                {gpsCapturing ? (
                  <Loader2 className="w-4 h-4 animate-spin" />
                ) : (
                  <MapPin className="w-4 h-4" />
                )}
                {gpsCapturing ? 'Capturing...' : 'Capture GPS'}
              </Button>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <Input
                type="text"
                value={endLat}
                placeholder="Latitude"
                readOnly
              />
              <Input
                type="text"
                value={endLng}
                placeholder="Longitude"
                readOnly
              />
            </div>
            {gpsWarning && (
              <div className="flex items-start gap-2 text-xs text-warning bg-warning/10 border border-warning/30 rounded-md p-2.5">
                <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" />
                <span>{gpsWarning}</span>
              </div>
            )}
            {gpsMetadata && !gpsWarning && (
              <p className="text-xs text-muted-foreground">
                Trust score: {gpsMetadata.trustScore}/100 · Accuracy: {gpsMetadata.accuracy != null ? `${Math.round(gpsMetadata.accuracy)}m` : '—'}
              </p>
            )}
          </div>

          {/* Notes */}
          <div className="space-y-1.5">
            <Label htmlFor="end_notes">Additional trip notes</Label>
            <Textarea
              id="end_notes"
              value={notes}
              onChange={e => setNotes(e.target.value)}
              rows={3}
              placeholder="Any additional notes about this trip..."
            />
          </div>

          {/* Post-trip vehicle disposition */}
          <div className="space-y-2">
            <Label>
              Vehicle after trip
              <span className="text-destructive ml-0.5">*</span>
            </Label>
            <p className="text-xs text-muted-foreground">Choose what happens to this vehicle after the trip ends.</p>
            <div className="grid grid-cols-2 gap-3">
              <button
                type="button"
                onClick={() => setPostTripChoice('available')}
                className={cn(
                  "flex flex-col items-start gap-1 p-3 rounded-lg border text-left transition-colors",
                  postTripChoice === 'available'
                    ? "border-primary bg-primary/5 ring-1 ring-primary"
                    : "border-border hover:bg-accent/50"
                )}
              >
                <Car className="w-4 h-4 text-emerald-500" />
                <span className="text-sm font-medium">Make available</span>
                <span className="text-xs text-muted-foreground">Vehicle returns to the pool</span>
              </button>
              <button
                type="button"
                onClick={() => setPostTripChoice('keep')}
                className={cn(
                  "flex flex-col items-start gap-1 p-3 rounded-lg border text-left transition-colors",
                  postTripChoice === 'keep'
                    ? "border-primary bg-primary/5 ring-1 ring-primary"
                    : "border-border hover:bg-accent/50"
                )}
              >
                <Clock className="w-4 h-4 text-indigo-500" />
                <span className="text-sm font-medium">Keep with me</span>
                <span className="text-xs text-muted-foreground">Held for your next trip</span>
              </button>
            </div>
          </div>

          {/* Live summary card — shows calculated distance once end odometer is entered */}
          {endOdometer && !odometerError && (
            <TripSummaryCard
              trip={{
                ...trip,
                end_odometer: parseFloat(endOdometer) || null,
                distance_km:
                  startOdo != null && endOdometer
                    ? Math.round((parseFloat(endOdometer) - startOdo) * 100) / 100
                    : null,
                end_trust_score: gpsMetadata?.trustScore ?? null,
              }}
            />
          )}

          <DialogFooter className="pt-4">
            <Button type="button" variant="outline" onClick={() => onClose(false)}>Cancel</Button>
            <Button
              type="submit"
              disabled={submitting || !endOdometer || !!odometerError || !endLat || !endLng || !postTripChoice}
            >
              {submitting ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  Completing...
                </>
              ) : (
                'Complete trip'
              )}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}